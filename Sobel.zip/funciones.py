import tkinter as tk 
from tkinter import ttk
from tkinter import *
from matplotlib import pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import pydicom 
import numpy as np
import os, sys
import cv2
import math
import copy
import math

VALUES = 65536


def histogram(RefDs):
	image = RefDs.pixel_array
	hist = [0]*VALUES
	for i in range (0,RefDs.Columns-1):
		for j in range(0,RefDs.Rows-1):
			index = image[i][j]
			hist[index]+=1
	return hist


def convolution(image, kernel):
	neighbors = len(kernel)//2
	newImage = [0]*len(image)

	for i in range (len(image)):
		newImage[i] = [0]*len(image[0])

	newImage= np.array(newImage)

	for i in range (neighbors, len(image)-neighbors):
		for j in range (neighbors,len(image[0])-neighbors):
			newImage[i-neighbors][j-neighbors]=np.sum(image[i-neighbors:i+neighbors+1,j-neighbors:j+neighbors+1]*kernel[:,:])

	return newImage


def sobel(image, neighbors):
	newImage = median(image, neighbors)
	sobelKernelX=np.array([[-1,0,1],[-2,0,2],[-1,0,1]])
	sobelKernelY=np.array([[-1,-2,-1],[0,0,0],[1,2,1]])
	gradientX= convolution(newImage, sobelKernelX)
	gradientY= convolution(newImage, sobelKernelX)
	gradient=[0]*len(newImage)
	angles=[0]*len(newImage)

	for i in range (len(newImage)):
		gradient[i] = [0]*len(newImage[0])
		angles[i] = [0]*len(newImage[0])

	gradient = np.array(gradient)
	angles = np.array(angles)

	gradient = np.absolute(gradientX) + np.absolute(gradientY)

	return gradient


def median(image, neighbors):
	newImage = [0]*len(image)

	for i in range (len(image)):
		newImage[i] = [0]*len(image[0])

	newImage= np.array(newImage)

	for i in range (neighbors, len(image)-neighbors):
		for j in range (neighbors,len(image[0])-neighbors):
			orderList = image[i-neighbors:i+neighbors+1,j-neighbors:j+neighbors+1].flatten()
			orderList.sort()
			size = len(orderList)
			median = orderList[math.ceil(size / 2)]
			newImage[i][j] = median

	return newImage


def thresholding(image):
	total = len(image)
	suma = sumaB = 0
	wB = wF = varMax = threshold = 0
	histograma = histogram(image)

	for i in range (50,VALUES):
		suma += i * histograma[i]

	for i in range (50,VALUES):
		wB += histograma[i]
		wF = total - wB

		if wF==0 :
			break

		sumaB += i*histograma[i]
		try:
			mB = sumaB / wB
			mF = (suma - sumaB) / wF
			varBetween = wB * wF * (mB - mF) * (mB - mF)

		except ZeroDivisionError:
			continue

		if (varBetween > varMax):
			varMax = varBetween
			threshold = i

	return threshold
